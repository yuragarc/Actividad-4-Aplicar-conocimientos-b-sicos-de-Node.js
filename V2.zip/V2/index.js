const fs = require('fs');
const readline = require('readline');

// Crear una interfaz de entrada/salida
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Función para determinar el estatus de edad
function evaluarEdad(edad) {
    return (edad >= 18) ? "Mayor de edad" : "Menor de edad";
}

// Preguntar al usuario por su nombre y edad
rl.question('¿Cuál es tu nombre completo? ', (nombreCompleto) => {
    rl.question('¿Cuál es tu edad? ', (edad) => {
        const estatus = evaluarEdad(Number(edad)); // Convertir a número y evaluar

        // Contenido a escribir en info.txt
        const contenido = `Nombre: ${nombreCompleto}\nEdad: ${edad}\nEstatus: ${estatus}`;

        // Crea o sobrescribe el archivo info.txt
        fs.writeFileSync('info.txt', contenido);
        console.log("Archivo info.txt creado con éxito!");

        // Cerrar la interfaz de lectura
        rl.close();
    });
});