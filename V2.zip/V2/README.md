# INFORME ACTIVIDAD 4

## ¿Qué hace el script?
El script genera un archivo `info.txt` que contiene el nombre, edad y estatus de una persona.

## ¿Qué aprendiste de Node.js?
He aprendido a usar Node.js para ejecutar JavaScript desde la terminal y trabajar con archivos.

## ¿Tuviste errores o dificultades?
No, pero al principio dudé sobre la sintaxis de los módulos.

## ¿Cómo lo ejecutarías en otra máquina?
Para ejecutar el script en otra máquina, necesitas tener Node.js instalado y clonar el repositorio.